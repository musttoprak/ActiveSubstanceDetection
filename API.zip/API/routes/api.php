<?php

use App\Http\Controllers\api\AuthController;
use App\Http\Controllers\api\PreparationsController;
use App\Http\Controllers\api\MedicineController;
use App\Http\Controllers\api\PriceMovementController;
use App\Http\Controllers\api\EquivalentController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Preparations Endpoints
Route::get('/preparations', [PreparationsController::class, 'index']);
Route::get('/preparations/search', [PreparationsController::class, 'search']);
Route::get('/preparations/{id}', [PreparationsController::class, 'show'])->where('id', '[0-9]+');


// Medicine Endpoints
Route::get('/medicines', [MedicineController::class, 'index']);
Route::get('/medicines/{id}', [MedicineController::class, 'show']);

// Price Movements Endpoints
Route::get('/price-movements', [PriceMovementController::class, 'index']);
Route::get('/price-movements/medicine/{medicineId}', [PriceMovementController::class, 'getByMedicine']);

// Equivalents Endpoints
Route::get('/equivalents', [EquivalentController::class, 'index']);
Route::get('/equivalents/medicine/{medicineId}', [EquivalentController::class, 'getByMedicine']);

Route::post('/login', [AuthController::class, 'login']);
