<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Equivalent extends Model
{
    protected $fillable = [
        'medicine_id',
        'error',
    ];
}
